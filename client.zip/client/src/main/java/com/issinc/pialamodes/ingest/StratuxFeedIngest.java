package com.issinc.pialamodes.ingest;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.xml.ws.ProtocolException;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StratuxFeedIngest 
{
    private static final Logger log = LoggerFactory.getLogger(StratuxFeedIngest.class);

    String feedHost = "172.20.6.146";
    int feedPort = 30003;
    URL callsignServerURL;
    URL positionServerURL;

    /**
     * Default ctor
     */
    public StratuxFeedIngest()
    {
        try
        {
            callsignServerURL = new URL("http://localhost:8090/callsign");
            positionServerURL = new URL("http://localhost:8090/position");
        }
        catch (MalformedURLException e)
        {
            log.error(e.getMessage());
        }
    }

    public StratuxFeedIngest(String serverHost, int serverPort)
    {
        try
        {
            this.callsignServerURL = new URL("http://" + serverHost + ":" + serverPort + "/callsign");
            this.positionServerURL = new URL("http://" + serverHost + ":" + serverPort + "/position");
        }
        catch (MalformedURLException e)
        {
            log.error(e.getMessage());
        }
    }
    
    /**
     * 
     * @param feedHost host for data feed
     * @param feedPort port for data feed
     * @param serverHost host for server to write to
     * @param serverPort port for server to write to
     */
    public StratuxFeedIngest(String feedHost, int feedPort, String serverHost, int serverPort)
    {
        this.feedHost = feedHost;
        this.feedPort = feedPort;
        try
        {
            this.callsignServerURL = new URL("http://" + serverHost + ":" + serverPort + "/callsign");
            this.positionServerURL = new URL("http://" + serverHost + ":" + serverPort + "/position");
        }
        catch (MalformedURLException e)
        {
            log.error(e.getMessage());
        }
    } 

    /**
     * 
     * @param filePath filePath to read scenario from
     */
    public void readScenario(String filePath)
    {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath));)
        {
            String line;
            Map<String, Position> posData = new HashMap<String, Position>();
            while ((line = br.readLine()) != null)
            {
                String[] lineParts = line.split(",");
                try
                {
                    long millis = Long.valueOf(lineParts[0]) / 1000000;
                    Thread.sleep(millis);
                    
                    if (lineParts[1].equals("MSG"))
                    {
                        String hexIdent = lineParts[5];
                        //ID Message
                        if (lineParts[2].equals("1"))
                        {
                            try
                            {
                                JSONObject callsign = new JSONObject();
                                callsign.put("hexIdent", hexIdent);
                                callsign.put("callsign", lineParts[11]);
                                String jsonString = callsign.toString();

                                HttpURLConnection conn = (HttpURLConnection) callsignServerURL.openConnection();
                                conn.setDoOutput(true);
                                conn.setRequestMethod("POST");
                                conn.setRequestProperty("Content-Type", "application/json");
                                OutputStream os = conn.getOutputStream();
                                os.write(jsonString.getBytes());
                                os.flush();
                                conn.getResponseCode();
                                conn.disconnect();
                            }
                            catch (JSONException e)
                            {
                                log.error("Failed to convert to JSON : " + e.getMessage());
                            }
                        }
                        //Surface Position Message
                        else if (lineParts[2].equals("2"))
                        {
                            Position position = posData.get(hexIdent);
                            if (position == null)
                            {
                                position = new Position(hexIdent);
                                posData.put(hexIdent, position);
                            }
                            if (StringUtils.isNotEmpty(lineParts[15]))
                            {
                                position.setLat(Double.valueOf(lineParts[15]));
                            }
                            if (StringUtils.isNotEmpty(lineParts[16]))
                            {
                                position.setLon(Double.valueOf(lineParts[16]));
                            }
                            if (StringUtils.isNotEmpty(lineParts[14]))
                            {
                                position.setHeading(Double.valueOf(lineParts[14]));
                            }
                            if (StringUtils.isNotEmpty(lineParts[13]))
                            {
                                position.setGroundSpeed(Double.valueOf(lineParts[13]));
                            }
                            if (position.isPositionFull())
                            {
                                sendPosition(position);
                                posData.remove(hexIdent);
                            }

                        }
                        //Airborne Position Message
                        else if (lineParts[2].equals("3"))
                        {
                            Position position = posData.get(hexIdent);
                            if (position == null)
                            {
                                position = new Position(hexIdent);
                                posData.put(hexIdent, position);
                            }
                            if (StringUtils.isNotEmpty(lineParts[15]))
                            {
                                position.setLat(Double.valueOf(lineParts[15]));
                            }
                            if (StringUtils.isNotEmpty(lineParts[16]))
                            {
                                position.setLon(Double.valueOf(lineParts[16]));
                            }
                            if (position.isPositionFull())
                            {
                                sendPosition(position);
                                posData.remove(hexIdent);
                            }
                        }
                        //Airborne Velocity Message
                        else if (lineParts[2].equals("4"))
                        {
                            Position position = posData.get(hexIdent);
                            if (position == null)
                            {
                                position = new Position(hexIdent);
                                posData.put(hexIdent, position);
                            }
                            if (StringUtils.isNotEmpty(lineParts[14]))
                            {
                                position.setHeading(Double.valueOf(lineParts[14]));
                            }
                            if (StringUtils.isNotEmpty(lineParts[13]))
                            {
                                position.setGroundSpeed(Double.valueOf(lineParts[13]));
                            }
                            if (StringUtils.isNotEmpty(lineParts[17]))
                            {
                                position.setVerticalRate(Double.valueOf(lineParts[17]));
                            }
                            if (position.isPositionFull())
                            {
                                sendPosition(position);
                                posData.remove(hexIdent);
                            }
                        }
                    }
                    
                }
                catch (Exception e)
                {
                    log.error("Failed to use line " + line);
                }
            }
        }
        catch (IOException e)
        {
            log.error("Failed to start scenario due to IO exception" + e.getMessage());
        }
    }

    /**
     * Read feed data
     */
    public void readFeed()
    {
        try (Socket socket = new Socket(feedHost, feedPort);
                BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));)
                {
            String line;

            StringBuilder builder = new StringBuilder();
            long trueStartTime = System.nanoTime();
            long lastReceived = trueStartTime;
            Map<String, Position> posData = new HashMap<String, Position>();
            while ((line = in.readLine()) != null)
            {
                log.info(line);
                // Build scenario
                long currentTime = System.nanoTime();
                long timeDif = currentTime - lastReceived;
                builder.append(timeDif + "," + line + "\n");
                if (currentTime - trueStartTime > 3.6e12)
                {
                    try (Writer writer = new BufferedWriter(new OutputStreamWriter(
                            new FileOutputStream("scenario-" + String.valueOf(trueStartTime) + ".txt"), "utf-8"))) 
                            {
                                writer.write(builder.toString());
                                builder = new StringBuilder();
                                trueStartTime = currentTime; 
                            }
                    catch (Exception e)
                    {
                        log.error ("Problem writing to file " + e.getMessage());
                    }
                    
                }
                lastReceived = currentTime;

                //Parse line
                String[] lineParts = line.split(",");
                if (lineParts[0].equals("MSG"))
                {
                    String hexIdent = lineParts[4];
                    //ID Message
                    if (lineParts[1].equals("1"))
                    {
                        try
                        {
                            JSONObject callsign = new JSONObject();
                            callsign.put("hexIdent", hexIdent);
                            callsign.put("callsign", lineParts[10]);
                            String jsonString = callsign.toString();

                            HttpURLConnection conn = (HttpURLConnection) callsignServerURL.openConnection();
                            conn.setDoOutput(true);
                            conn.setRequestMethod("POST");
                            conn.setRequestProperty("Content-Type", "application/json");
                            OutputStream os = conn.getOutputStream();
                            os.write(jsonString.getBytes());
                            os.flush();
                            conn.getResponseCode();
                            conn.disconnect();
                        }
                        catch (JSONException e)
                        {
                            log.error("Failed to convert to JSON : " + e.getMessage());
                        }
                    }
                    //Surface Position Message
                    else if (lineParts[1].equals("2"))
                    {
                        Position position = posData.get(hexIdent);
                        if (position == null)
                        {
                            position = new Position(hexIdent);
                            posData.put(hexIdent, position);
                        }
                        if (StringUtils.isNotEmpty(lineParts[14]))
                        {
                            position.setLat(Double.valueOf(lineParts[14]));
                        }
                        if (StringUtils.isNotEmpty(lineParts[15]))
                        {
                            position.setLon(Double.valueOf(lineParts[15]));
                        }
                        if (StringUtils.isNotEmpty(lineParts[13]))
                        {
                            position.setHeading(Double.valueOf(lineParts[13]));
                        }
                        if (StringUtils.isNotEmpty(lineParts[12]))
                        {
                            position.setGroundSpeed(Double.valueOf(lineParts[12]));
                        }
                        if (position.isPositionFull())
                        {
                            sendPosition(position);
                            posData.remove(hexIdent);
                        }

                    }
                    //Airborne Position Message
                    else if (lineParts[1].equals("3"))
                    {
                        Position position = posData.get(hexIdent);
                        if (position == null)
                        {
                            position = new Position(hexIdent);
                            posData.put(hexIdent, position);
                        }
                        if (StringUtils.isNotEmpty(lineParts[14]))
                        {
                            position.setLat(Double.valueOf(lineParts[14]));
                        }
                        if (StringUtils.isNotEmpty(lineParts[15]))
                        {
                            position.setLon(Double.valueOf(lineParts[15]));
                        }
                        if (position.isPositionFull())
                        {
                            sendPosition(position);
                            posData.remove(hexIdent);
                        }
                    }
                    //Airborne Velocity Message
                    else if (lineParts[1].equals("4"))
                    {
                        Position position = posData.get(hexIdent);
                        if (position == null)
                        {
                            position = new Position(hexIdent);
                            posData.put(hexIdent, position);
                        }
                        if (StringUtils.isNotEmpty(lineParts[13]))
                        {
                            position.setHeading(Double.valueOf(lineParts[13]));
                        }
                        if (StringUtils.isNotEmpty(lineParts[12]))
                        {
                            position.setGroundSpeed(Double.valueOf(lineParts[12]));
                        }
                        if (StringUtils.isNotEmpty(lineParts[16]))
                        {
                            position.setVerticalRate(Double.valueOf(lineParts[16]));
                        }
                        if (position.isPositionFull())
                        {
                            sendPosition(position);
                            posData.remove(hexIdent);
                        }
                    }
                }
            }
                }
        catch (IOException e)
        {
            log.error(e.getStackTrace().toString());
        }
    }



    /**
     * 
     * @param positionData position data to use
     */
    private void sendPosition(Position positionData)
    {
        try
        {
            JSONObject hexIdent = new JSONObject();
            hexIdent.put("hexIdent", positionData.getHexIdent());

            JSONObject position = new JSONObject();
            position.put("positionId", hexIdent);
            position.put("hexIdent", positionData.getHexIdent());
            position.put("heading", positionData.getHeading());
            position.put("lat", positionData.getLat());
            position.put("lon", positionData.getLon());
            position.put("groundSpeed", positionData.getGroundSpeed());
            position.put("verticalRate", positionData.getVerticalRate());
            String jsonString = position.toString();

            HttpURLConnection conn = (HttpURLConnection) positionServerURL.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            OutputStream os = conn.getOutputStream();
            os.write(jsonString.getBytes());
            os.flush();
            conn.getResponseCode();
            conn.disconnect();
        }
        catch (JSONException e)
        {
            log.error("Failed to convert to JSON : " + e.getMessage());
        }
        catch (IOException pe)
        {
            log.error("Failed to connect with exception : " + pe.getMessage());
        }
    }
}
