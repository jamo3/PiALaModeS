package com.issinc.pialamodes.ingest;


public class Position 
{

    private String hexIdent;
    private Double heading = null;
    private Double lat = null;
    private Double lon = null;
    private Double groundSpeed = null;
    private Double verticalRate = null;

    /**
     * 
     * @param hexIdent hex identifier
     */
    public Position(String hexIdent)
    {
        this.hexIdent = hexIdent;
    }
    /**
     * 
     * @return hex identifier
     */
    public String getHexIdent() 
    {
        return hexIdent;
    }

    /**
     * 
     * @param hexIdent hex identifier
     */
    public void setHexIdent(String hexIdent) 
    {
        this.hexIdent = hexIdent;
    }

    /**
     * 
     * @return heading
     */
    public Double getHeading() 
    {
        return heading;
    }

    /**
     * 
     * @param heading heading
     */
    public void setHeading(double heading) 
    {
        this.heading = heading;
    }

    /**
     * 
     * @return latitude
     */
    public Double getLat() 
    {
        return lat;
    }

    /**
     * 
     * @param lat latitude
     */
    public void setLat(double lat) 
    {
        this.lat = lat;
    }

    /**
     * 
     * @return longitude
     */
    public Double getLon() 
    {
        return lon;
    }

    /**
     * 
     * @param lon longitude
     */
    public void setLon(double lon) 
    {
        this.lon = lon;
    }

    /**
     * 
     * @return ground speed
     */
    public Double getGroundSpeed() 
    {
        return groundSpeed;
    }

    /**
     * 
     * @param groundSpeed ground speed
     */
    public void setGroundSpeed(double groundSpeed) 
    {
        this.groundSpeed = groundSpeed;
    }

    /**
     * 
     * @return vertical rate
     */
    public Double getVerticalRate() 
    {
        return verticalRate;
    }

    /**
     * 
     * @param verticalRate vertical rate
     */
    public void setVerticalRate(double verticalRate) 
    {
        this.verticalRate = verticalRate;
    }
    
    /**
     * 
     * @return is the position fully populated
     */
    public boolean isPositionFull()
    {
        return (heading != null && lat != null && lon !=null && groundSpeed != null && verticalRate != null);
    }
    
}
