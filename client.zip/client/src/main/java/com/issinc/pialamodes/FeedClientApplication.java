package com.issinc.pialamodes;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.issinc.pialamodes.ingest.StaticDataIngest;
import com.issinc.pialamodes.ingest.StratuxFeedIngest;


public class FeedClientApplication 
{

    private static final Logger log = LoggerFactory.getLogger(FeedClientApplication.class);
    public static void main(String[] args) 
    {
        String feedHost = "172.20.6.146";
        int feedPort = 30003;
        String serverHost = "172.20.6.146";
        int serverPort = 8090;
        
        boolean useScenarioData = false;
        String scenarioDataFile = null;
        
        boolean loadStaticData = false;
        String modelFile = null;
        String masterFile = null;
        
        int len = args.length;
        for (int i = 0; i < len; i++)
        {
            if ("-feedHost".equals(args[i]) && len > i + 1)
            {
                feedHost = args[i+1];
                i++;
            }
            else if ("-feedPort".equals(args[i]) && len > i + 1)
            {
                try
                {
                    feedPort = Integer.valueOf(args[i+1]);
                }
                catch (NumberFormatException e)
                {
                    log.error("Failed to translate " + args[i+1] + " into a valid integer, using default feed port of " + feedPort);
                }
                i++;
            }
            else if ("-serverHost".equals(args[i]) && len > i + 1)
            {
                serverHost = args[i+1];
                i++;
            }
            else if ("-serverPort".equals(args[i]) && len > i + 1)
            {
                try
                {
                    serverPort = Integer.valueOf(args[i+1]);
                }
                catch (NumberFormatException e)
                {
                    log.error("Failed to translate " + args[i+1] + " into a valid integer, using default server port of " + serverPort);
                }
            }
            else if ("-loadStaticData".equals(args[i]) && len > i + 2)
            {
                loadStaticData = true;
                modelFile = args[i+1];
                masterFile = args[i+2];
            }
            else if ("-useScenarioData".equals(args[i]) && len > i + 1)
            {
                useScenarioData = true;
                scenarioDataFile = args[i+1];
            }
        }
        if (loadStaticData)
        {
            StaticDataIngest sdIngest = new StaticDataIngest();
            sdIngest.ingest(modelFile, masterFile);
        }
        
        
        if (useScenarioData)
        {
            StratuxFeedIngest sfIngest = new StratuxFeedIngest(serverHost, serverPort);
            
            sfIngest.readScenario(scenarioDataFile);
        }
        else
        {   
            StratuxFeedIngest sfIngest = new StratuxFeedIngest(feedHost, feedPort, serverHost, serverPort);
            sfIngest.readFeed();
        }
    }
}
